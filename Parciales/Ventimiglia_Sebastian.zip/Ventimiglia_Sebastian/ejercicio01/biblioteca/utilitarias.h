#ifndef UTILITARIAS_H_INCLUDED
#define UTILITARIAS_H_INCLUDED

void mostrarMensajeError(const char * mensaje);

#endif // UTILITARIAS_H_INCLUDED
